import React from 'react'

function Home() {
    const users = useSelector((state)=>state.users) 
  return (
    <div className='main'>
        <div className='ui secondary button'>
            create + 
        </div>
        <h2></h2>
        <table>
          <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
          </thead>
        </table>
        
    </div>
  )
}

export default Home